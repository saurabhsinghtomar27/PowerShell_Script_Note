public class Binary{
    public static void main(String[] args) {
        // int number=13;
        // String res="";
        // while (number>0) {
        //     if(number%2==1)
        //        res="1"+res;
        //     else
        //     res="0"+res;
        //     number=number/2;   
        // }
        // System.out.println("Binary :"+res);
        int a=5;
        int c=1;
        int d=1<<c;
       

    }
}